# DBMS = "mongodb"
#
# DATABASE_NAME = 't-building'
# TABLE_NAME = "residentinfo"
#
# RAW_PATH = f"/data/{DBMS}/{DATABASE_NAME}/{TABLE_NAME}/raw/delta"
#
# BRONZE_PATH = f"/data/{DBMS}/{DATABASE_NAME}/{TABLE_NAME}/bronze/delta"
#
# SILVER_PATH = f"/data/{DBMS}/{DATABASE_NAME}/{TABLE_NAME}/bronze/delta"
#
#
# class Constants:
#
#     def __init__(self):
#         self.DBMS = "mongodb"
#         self.DATABASE_NAME = "t-building"
#         self.TABLE_NAME = "residentinfo"
#
#     @staticmethod
#     def get_raw_path():
#         return f"/data/{DBMS}/{DATABASE_NAME}/{TABLE_NAME}/raw/delta"
#
#     @staticmethod
#     def get_bronze_path():
#         return f"/data/{DBMS}/{DATABASE_NAME}/{TABLE_NAME}/bronze/delta"
#
#     @staticmethod
#     def get_
#
