import pyspark.sql.types as sql_type
from pyspark.sql.functions import when, col, regexp_replace
from pyspark.sql import SparkSession
from pyspark.sql.functions import udf
from pyspark.sql import DataFrame


# GLOBAL VARIABLES

DBMS = "mysql"

DATABASE_NAME = "synthea"

TABLE_NAME = "patients"

SOURCE_PATH = f"/data/{DBMS}/{DATABASE_NAME}/{TABLE_NAME}/silver/delta"

TARGET_PATH = f"/data/{DBMS}/{DATABASE_NAME}/{TABLE_NAME}/gold/delta"



def extract(spark: SparkSession):
    try:
        raw_df = spark.read.format('delta').load(SOURCE_PATH)
        return raw_df
    except Exception as e:
        raise Exception(f"Error in extract: {e}")

def transform(silver_df: DataFrame):
    try:
        silver_df = silver_df.withColumn("FIRST", regexp_replace(col("FIRST"), "[0-9]", "")) \
                            .withColumn("LAST", regexp_replace(col("LAST"), "[0-9]", ""))\
                            .withColumn("MAIDEN", regexp_replace(col("MAIDEN"), "[0-9]", ""))
        
        silver_df = silver_df.fillna("no maiden", subset=["Maiden"])

        silver_df =  silver_df.withColumn("Gender", when(col("Gender") == "F", "Female").otherwise("Male"))
        
        return silver_df
    except Exception as e:
        raise Exception(f"Error in transform: {e}")

def load(silver_df: DataFrame):
    try:
        silver_df.write.format("delta").mode("overwrite").save(TARGET_PATH)
    except Exception as e:
        raise Exception(f"Error in load: {e}")

def process_Gold(spark: SparkSession):
    try:
        silver_df = extract(spark)
        gold_df = transform(silver_df)
        load(gold_df)
    except Exception as e:
        msg = f"Something went wrong in silver program - {e}"
        raise Exception(msg)