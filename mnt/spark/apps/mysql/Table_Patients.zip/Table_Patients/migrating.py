from pyspark.sql import SparkSession
from pyspark.sql import functions as func
from delta.tables import *
from pyspark.sql import DataFrame
from datetime import datetime
DBMS = "mysql"

DATABASE_NAME = "synthea"

TABLE_NAME = "patients"

TARGET_PATH = f"/data/{DBMS}/{DATABASE_NAME}/{TABLE_NAME}/raw/delta"
mysql_properties = {
    "url": "jdbc:mysql://192.168.195.84:3306/synthea",
    "driver": "com.mysql.jdbc.Driver",
    "user": "mysqluser",
    "password": "mysqlpw"
}
# 172.22.0.4 is the IP address of the mongo container

SELECTED_COLUMNS = ['Id', 'BIRTHDATE', 'DEATHDATE', 'SSN', 'DRIVERS', 'PASSPORT', 'PREFIX','FIRST','LAST','SUFFIX','MAIDEN','MARITAL','RACE','ETHNICITY'
                    'GENDER','BIRTHPLACE','ADDRESS','CITY','STATE','COUNTY','FIPS','ZIP','LAT','LON','HEALTHCARE_EXPENSES','HEALTHCARE_COVERAGE','INCOME']

def extract(spark: SparkSession) -> DataFrame:
    try:
        mysql_df = spark.read.jdbc(url=mysql_properties["url"],
                                    table=TABLE_NAME,
                                    properties=mysql_properties)

        return mysql_df
    except Exception as e:
        raise (e, "extract")


def load(mysql_df: DataFrame):
    try:
        mysql_df.write.format("delta").mode("overwrite").save(TARGET_PATH)
    except Exception as e:
        raise (e, "load")

def process_Migration(spark: SparkSession):
    try:
        bronze_df = extract(spark)
        # silver_df = transform(bronze_df)
        load(bronze_df)
    except Exception as e:
        msg = f"Something went wrong in migrating program - {e}"
        raise Exception(msg)