import pyspark.sql.types as sql_type
from pyspark.sql.functions import col, date_format
from pyspark.sql import SparkSession
from pyspark.sql.functions import udf
from pyspark.sql import DataFrame


# GLOBAL VARIABLES

DBMS = "mysql"

DATABASE_NAME = 'synthea'
TABLE_NAME = "payper_transitions"

SOURCE_PATH = f"/data/{DBMS}/{DATABASE_NAME}/{TABLE_NAME}/silver/delta"

TARGET_PATH = f"/data/{DBMS}/{DATABASE_NAME}/{TABLE_NAME}/gold/delta"



def extract(spark: SparkSession):
    try:
        raw_df = spark.read.format('delta').load(SOURCE_PATH)
        return raw_df
    except Exception as e:
        raise Exception(f"Error in extract: {e}")

def transform(silver_df: DataFrame):
    try:
        silver_df = silver_df.withColumnRenamed("PATIENT","PATIENTID") \
                            .withColumnRenamed("PAYER","PAYERID")
        # remove duplicate
        silver_df = silver_df.drop_duplicates()
        # convert datetime
        silver_df = silver_df.withColumn("START_DATE", date_format(col("START_DATE"), "yyyy-MM-dd")) \
                             .withColumn("END_DATE", date_format(col("END_DATE"),"yyyy-MM-dd"))
        
        return silver_df
    except Exception as e:
        raise Exception(f"Error in transform: {e}")

def load(silver_df: DataFrame):
    try:
        silver_df.write.format("delta").mode("overwrite").save(TARGET_PATH)
    except Exception as e:
        raise Exception(f"Error in load: {e}")

def process_Gold(spark: SparkSession):
    try:
        silver_df = extract(spark)
        gold_df = transform(silver_df)
        load(gold_df)
    except Exception as e:
        msg = f"Something went wrong in silver program - {e}"
        raise Exception(msg)