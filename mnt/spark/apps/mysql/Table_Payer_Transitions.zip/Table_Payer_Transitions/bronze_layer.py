from pyspark.sql import SparkSession
from pyspark.sql import functions as func
from pyspark.sql.window import Window
from pyspark.sql import DataFrame


# GLOBAL VARIABLES

DBMS = "mysql"

DATABASE_NAME = 'synthea'
TABLE_NAME = "payer_transitions"

SOURCE_PATH = f"/data/{DBMS}/{DATABASE_NAME}/{TABLE_NAME}/raw/delta"

TARGET_PATH = f"/data/{DBMS}/{DATABASE_NAME}/{TABLE_NAME}/bronze/delta"


def extract(spark: SparkSession) -> DataFrame:
    try:
        raw_df = spark.read.format("delta").load(SOURCE_PATH)
        return raw_df
    except Exception as e:
        raise Exception(f"Error in extract: {e}")

def load(bronze_df: DataFrame) -> None:
    try:
        bronze_df.write.format("delta").mode("overwrite").save(TARGET_PATH)
    except Exception as e:
        raise Exception(f"Error in load: {e}")
        
def process_Bronze(spark):
    try:
        bronze_df = extract(spark)
        # silver_df = transform(bronze_df)
        load(bronze_df)
    except Exception as e:
        msg = f"Something went wrong in bronze program - {e}"
        raise Exception(msg)