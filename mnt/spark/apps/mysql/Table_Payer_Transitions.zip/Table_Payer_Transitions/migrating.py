from pyspark.sql import SparkSession
from pyspark.sql import functions as func
from delta.tables import *
from pyspark.sql import DataFrame
from datetime import datetime
DBMS = "mysql"

DATABASE_NAME = 'synthea'
TABLE_NAME = "payer_transitions"

TARGET_PATH = f"/data/{DBMS}/{DATABASE_NAME}/{TABLE_NAME}/raw/delta"
mysql_properties = {
    "url": "jdbc:mysql://192.168.195.84:3306/synthea",
    "driver": "com.mysql.jdbc.Driver",
    "user": "mysqluser",
    "password": "mysqlpw"
}
# 172.22.0.4 is the IP address of the mongo container
MYSQL_URI = f""

SELECTED_COLUMNS = ['PATIENT', 'MEMBERID', 'START_DATE', 'END_DATE', 'PAYER', 'SECONDARY_PAYER', 'PLAN_OWNERSHIP',
                    'OWNER_NAME']

def extract(spark: SparkSession) -> DataFrame:
    try:
        mysql_df = spark.read.jdbc(url=mysql_properties["url"],
                                    table=TABLE_NAME,
                                    properties=mysql_properties)

        return mysql_df
    except Exception as e:
        raise Exception (e, "extract")


def load(mysql_df: DataFrame):
    try:
        mysql_df.write.format("delta").mode("overwrite").save(TARGET_PATH)
    except Exception as e:
        raise Exception (e, "load")

def process_Migration(spark: SparkSession):
    try:
        bronze_df = extract(spark)
        # silver_df = transform(bronze_df)
        load(bronze_df)
    except Exception as e:
        msg = f"Something went wrong in migrating program - {e}"
        raise Exception(msg)