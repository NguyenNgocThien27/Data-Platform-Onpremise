import pyspark.sql.types as sql_type
import pyspark.sql.functions as func
from pyspark.sql import SparkSession
from pyspark.sql.functions import udf
from pyspark.sql import DataFrame


# GLOBAL VARIABLES

DBMS = "mysql"

DATABASE_NAME = 'synthea'
TABLE_NAME = "payer_transitions"

SOURCE_PATH = f"/data/{DBMS}/{DATABASE_NAME}/{TABLE_NAME}/bronze/delta"

TARGET_PATH = f"/data/{DBMS}/{DATABASE_NAME}/{TABLE_NAME}/silver/delta"


def extract(spark: SparkSession):
    try:
        raw_df = spark.read.format('delta').load(SOURCE_PATH)
        return raw_df
    except Exception as e:
        raise Exception(f"Error in extract: {e}")



def load(silver_df: DataFrame):
    try:
        silver_df.write.format("delta").mode("overwrite").save(TARGET_PATH)
    except Exception as e:
        raise Exception(f"Error in load: {e}")

def process_Silver(spark: SparkSession):
    try:
        silver_df = extract(spark)
        # silver_df = transform(bronze_df)
        load(silver_df)
    except Exception as e:
        msg = f"Something went wrong in silver program - {e}"
        raise Exception(msg)